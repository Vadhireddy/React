const square= function(x){
return x*x
}

const squareArrow = (x) => {
    return x*x;
}

const abc = (x) => x*x;
console.log(abc(12));

const getfirstname= (x) => (x.split(' ')[0]);
console.log(getfirstname('Dinesh Kumar Reddy'));