class Person{
    constructor(name){
        this.name = name;
    }

}

const me = new Person('Dinesh K Reddy');
console.log(me);