class Person {
    constructor(name='Anonymous', age){
        this.name = name ;        
        this.age = age;
    }
    getDescription()
    {
        return `Hi Iam  ${this.name} and aged ${this.age}`;
    }
}

/*
class Student extends Person{
    constructor(name,age, major){
        super(name,age);
        this.major = major;
    }
    
    
    getDescription()
    {
        let test = super.getDescription();
        if(major){
            test = test + ` and have majored in ${this.major}`;
        }
        return test;
        //return `Hi Iam ${this.name} aged ${this.age} with Degree ${this.major}`;
    }

}
*/
class Traveler extends Person(){
    constructor(name,age,location){
        super(name,age);
        this.Location = location;
    }

    getGreetings(){
        let abc = super.getDescription();
        if(Location){
            abc += `and Im from ${this.Location}`;
        }
        return abc;
    }
}
/*var classObj = new Person('Dinesh Kumar Reddy',30);
console.log(classObj.getDescription());

var classObj2 = new Person();
console.log(classObj2.getDescription()); 

var studentObj = new Student('Dinesh Kumar Reddy',30, 'EEE');
console.log(studentObj.getDescription());

var studentObj2 = new Student();
console.log(studentObj2.getDescription());*/

var travelerObj = new Traveler('Dinesh Kumar Reddy',30, 'Banglore');
console.log(travelerObj);

var travelerObj2 = new Traveler();
console.log(travelerObj2);