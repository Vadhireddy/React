
let count=0;
const add = () => {
    count++;
   console.log(count);
   //document.getElementById("hOne").innerText= 'Count is '+ count++;
   rerenderCounterApp();
};  

const sub=()=> {
    count--;
    console.log(count);
    //document.getElementById("hOne").innerText = 'Count is '+ count--;
    rerenderCounterApp();
};







const rerenderCounterApp = () =>{
    var template3 =(
        <div>
            <h1 id='hOne'>Count : {count}</h1>
            <button onClick={add}>Add</button>
            <button onClick={sub}>Subtract</button>
        </div>
    
    );
    ReactDOM.render(template3,htmlcontrol);    
}

rerenderCounterApp();