

var userobject=
{
    name:'Dinesh',
    age:'33',
    location:'Banglore'
}

var abc =
{
    Title:'Main Title',
    SubTitle:'SubTitle',
    options:[]
}

const onformsubmitevent=(e) => {
    e.preventDefault();
    var textvalue = e.target.elements.text1.value;
    console.log(textvalue);
    if(textvalue)
    {
        abc.options.push(textvalue);
        e.target.elements.text1.value ="";
    }
    rerenderfunction();
};

const ClearFunction=(e) =>
{
    e.preventDefault();
    abc.options=[];
    rerenderfunction();
}

var template2 = (
<div>
    <h1>Name : {userobject.name}</h1>
    <p>{userobject.age > 18 && 'Age=' + userobject.age}</p>
    <h1>{userobject.location ? userobject.location : 'Location Unknown' }</h1>
</div>);

function subtitlepoints(subtitle)
{
 if(subtitle)
 {
     var jsxml =  <div><p>{subtitle}</p> <ol> <li>Test1</li><li>Test1</li> <li>Test1</li> </ol></div>;

return jsxml;
 }
}

var htmlcontrol =  document.getElementById('app1');

const rerenderfunction = () => {

    var template = (<div><h1>{abc.Title}</h1>
        <div>{subtitlepoints(abc.SubTitle)}</div>
    <p>{abc.options.length}</p>
        <form onSubmit={onformsubmitevent}>
            <input type="text" name="text1"></input>
            <button name="btn">Add Button</button>
            <button name="clear" onClick={ClearFunction}>clear Button</button>
            <ol>
                {abc.options.map((value) =>  
                {
                    return <li key={value}>{value}</li>;                
                })
                
                }            
            </ol>
            
        </form>
        </div>
        );
        ReactDOM.render(template,htmlcontrol);    

}

let buttontext = "";
let hiddenbool=false;
const Toggle =() => {
if(hidden)
{
    return false,buttontext='Hide toggle';
}
else{
    return true,buttontext='UnHide toggle';
}
}

const visibilityToggle = () =>{
    var templatetoggle = (<div>
        <h1>Visibility Toggle</h1>
    <input >Btn text </input>
    <p >sdasahahajladjakdka;dka;s</p>
    </div>);
    ReactDOM.render(templatetoggle,htmlcontrol); 
    //rerenderfunction(); 
}
rerenderfunction();
//visibilityToggle();