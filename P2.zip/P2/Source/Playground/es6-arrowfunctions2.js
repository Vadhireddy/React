const add = function(a,b){

    console.log(arguments);
    return(a+b);
}


const add2=(a,b) => {
    //console.log(arguments);
    return(a+b);
}

const user = {

    name:'Dinesh',
    destinations:['KTP','KDR','ATP','GTY','BLR','HYD'],
    numbers:[20,30,40],
    multiplyby : 10,
    abc (){
        console.log(this.name);
        console.log(this.destinations);
        
        this.destinations.forEach((city) =>
        {
            console.log(this.name +' Lived in ' + city);

        });
    },
    multiply(){
        console.log(this.multiplyby);
        console.log(this.numbers);
        return this.numbers.map((number) => number * this.multiplyby);
    }
};

//user.abc();
console.log(user.multiply());

